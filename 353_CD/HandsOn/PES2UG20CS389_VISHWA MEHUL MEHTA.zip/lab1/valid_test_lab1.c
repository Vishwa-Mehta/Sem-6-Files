#include <stdio.h>
int main()
{
	int a, b, i = 0;
	float d, e;
	int a_1;
	a_1 = 1 + 2 - 3 / 4 * 5 + (a < (b * 20));
	if(a < b)
		a = 10;
	if(a >= b)
	{
		a = 131 * 4436 / 2045 + 5360;
	}
	do
		while(a < b && a == b)
			while(a >= b)
			{
				int a_3;
				a_3 = 3323 == 2665 + 297 > 5816;
				int a_4;
				a_4 = 6423 + 3661 + 1998 * 9083;
			}
	while(a < b);
}
		
