#include <stdio.h>
int main()
{
	int a, b, i = 0;
	float d, e;
	int 1;
