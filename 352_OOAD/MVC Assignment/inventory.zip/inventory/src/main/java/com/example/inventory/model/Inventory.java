package com.example.inventory.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "inventory")
public class Inventory {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false)
  private String productId;

  @Column(nullable = false)
  private String productName;

  @Column(nullable = false)
  private String price;

  @Column(nullable = false)
  private String qty;

  public Inventory() {
  }

  public Inventory(String productId, String productName, String price, String qty) {
    this.productId = productId;
    this.productName = productName;
    this.price = price;
    this.qty = qty;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getPId() {
    return productId;
  }

  public void setPId(String productId) {
    this.productId = productId;
  }

  public String getProdName() {
    return productName;
  }

  public void setProdName(String productName) {
    this.productName = productName;
  }

  public String getPrice() {
    return price;
  }

  public void setPrice(String price) {
    this.price = price;
  }

  public String getQty() {
    return qty;
  }

  public void setQty(String qty) {
    this.qty = qty;
  }
}